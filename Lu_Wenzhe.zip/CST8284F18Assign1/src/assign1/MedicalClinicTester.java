/* File Name: MedicalClinicTester.java
* Course Name: CST8284
* Lab Section: 313
* Student Name: Wenzhe Lu
* Date: 2018-10-08
*/

package assign1;


public class MedicalClinicTester {

	public static void main(String[] args) {
		MedicalClinic mc = new MedicalClinic();
		mc.menu();
	}

}
